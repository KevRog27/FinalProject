package src;


/**
 * Flight Patterns of Enemy
 *
 * @author Paul Berend
 * @version (version number or date here)
 */
public enum EnemyMode {
    FLYING,
    FORMATION
}
