package src;

import java.util.LinkedList;

import mayflower.*;
/**
 * Level One. 
 */
public class LevelOne extends MyWorld
{
    /**
     * Creates level one, wiht 17 Enemies.
     */
    public LevelOne()
    {
        super("./assets/textures/backgrounds/level1.png");
        
        
        EnemyWave wave = new EnemyWave();
        EnemyChain e1 = new EnemyChain(this, 310, -20, 5);
        EnemyChain e2 = new EnemyChain(this, 310, -20, 7);
        EnemyChain e3 = new EnemyChain(this, 310, -20, 5);
        enemyChains.add(e1);
        enemyChains.add(e2);
        enemyChains.add(e3);
        
        wave.addEnemyToWave(e1, 1);
        wave.addEnemyToWave(e2, 5);
        wave.addEnemyToWave(e3, 5);
        
        addObject(wave, -30, -30);
        
        wave.activateWave();

        waves = new LinkedList<EnemyWave>();
        waves.add(wave);
    }
    /**
     * Sends player to next level when all enemies are dead.
     */
    public void act(){
        super.act();
            
        if(waves.get(0).waveIsDone())
            Mayflower.setWorld(new LevelTwo());
                
    }
    
}