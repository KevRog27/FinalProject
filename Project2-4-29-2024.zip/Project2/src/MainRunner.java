package src;


/**
 * Runner class for the game.
 *
 * @author Paul Berend
 * @version 4-24
 */
public class MainRunner
{
    /**
     * Creates a new game instance.
     */
    public static void main(String[] args){
        new Main();
    }
}
