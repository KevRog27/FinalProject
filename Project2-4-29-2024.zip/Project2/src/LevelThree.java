package src;

import java.util.LinkedList;

import mayflower.*;
/**
 * Level Three.
 */
public class LevelThree extends MyWorld
{
    /**
     * Creates level one, wiht 50 Enemies.
     */
    public LevelThree()
    {
        super("./assets/textures/backgrounds/level3.png");

         EnemyWave wave = new EnemyWave();
        EnemyChain e1 = new EnemyChain(this, 310, -20, 50);

        enemyChains.add(e1);

        wave.addEnemyToWave(e1, 1);
        
        addObject(wave, -30, -30);
        
        wave.activateWave();

        waves = new LinkedList<EnemyWave>();
        waves.add(wave);
    }
    /**
     * Sends player to next level when all enemies are dead.
     */
    public void act(){
        super.act();
        
        if(jet.getLives() <= 0)
            Mayflower.setWorld(new GameOver("LOSE"));
            
        if(waves.get(0).waveIsDone())
            Mayflower.setWorld(new GameOver("WIN"));
                
    }
    
}