package src;

import mayflower.*;

/**
 * Game Over Screen.
 */
public class GameOver extends World
{
    /**
     * Create the instance, setting the background based on whether you got here by dying or winning.
     */
    public GameOver(String outcome)
    {
        MayflowerImage img;
        if(outcome.equals("LOSE")){
            img = new MayflowerImage("./assets/textures/gameover/gameOverLose.png");
        }else{
            img = new MayflowerImage("./assets/textures/gameover/gameOverWin.png");
        }
        img.scale(640, 480);
        setBackground(img);
    }
    
    /**
     * Scene Logic. Advances to the title screen when enter is pressed.
     */
    public void act(){
        if(Mayflower.isKeyDown(Keyboard.KEY_ENTER)){
            Mayflower.setWorld(new TitleScreen());
            MyWorld.jet = null;
            MyWorld.previousBackground = null;
        }
    }
}
