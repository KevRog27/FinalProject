package src;

import mayflower.*;

/**
 * Explosion for the death of any jet. 
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Explosion extends AnimatedActor
{
    private Animation boom;
    
    /**
     * Creates a new explosion.
     */
    public Explosion()
    {
        String[] pics = new String[6];
        
        for(int i = 1; i <= pics.length; i++){
            pics[i - 1] = "./assets/textures/explosion/explosion" + i + ".png";
        }
        
        boom = new Animation(pics, 24/60);
        boom.resize(25, 25);
        
        MayflowerImage img = new MayflowerImage(pics[0]);
        img.scale(25, 25);
        setImage(img);
        setAnimation(boom);
    }
    
    /**
     * Explosion Logic. Removes the object when animation is complete.
     */
    public void act(){
        super.act();
        if(boom.isDone()) getWorld().removeObject(this);
    }
    
}
