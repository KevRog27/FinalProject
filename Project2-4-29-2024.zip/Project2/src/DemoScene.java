package src;

import mayflower.*;
import java.util.*;

/**
 * DemoScene used for testing. 
 */
public class DemoScene extends World
{
    ArrayList<EnemyChain> enemyChains;
    public static boolean DEBUG = false;
    EnemyWave currentWave;
    Queue<EnemyWave> waves = new LinkedList<EnemyWave>();
    public static Player p;
    mayflower.Timer flopTimer;
    int timerCount = 0;

    public DemoScene(){
        if(p == null) p = new Player(this, 310, 440);
        
        enemyChains = new ArrayList<EnemyChain>();
        
        // Define Waves
        
        // Wave 1
        EnemyWave wave = new EnemyWave();
        EnemyChain e1 = new EnemyChain(this, 310, -20, 5);
        EnemyChain e2 = new EnemyChain(this, 310, -20, 7);
        EnemyChain e3 = new EnemyChain(this, 310, -20, 5);
        enemyChains.add(e1);
        enemyChains.add(e2);
        enemyChains.add(e3);
        
        wave.addEnemyToWave(e1, 15);
        wave.addEnemyToWave(e2, 15);
        wave.addEnemyToWave(e3, 15);
        
        addObject(wave, -30, -30);
        
        wave.activateWave();
        waves.add(wave);
        
        
        //enemyChains.get(0).setActive(true);
        flopTimer = new mayflower.Timer((int)(1e9*2));
    }
    /**
     * DemoScene Logic.
     */
    public void act(){
        if(DEBUG&&Mayflower.isKeyPressed(Keyboard.KEY_P)) {
            for(EnemyChain e : enemyChains.toArray(new EnemyChain[0])){
                EnemyChain[] newChains = e.split();
                if(newChains[0].size() > 0) enemyChains.add(newChains[0]);
                if(newChains[1].size() > 0) enemyChains.add(newChains[1]);
            }
        }
        if(DEBUG&&Mayflower.isKeyPressed(Keyboard.KEY_L)) {
            for(EnemyChain e : enemyChains) e.setActive(!e.getActive());
        }
        // Wait until wave is completely dead to move on to the next wave. 
        if(waves.size() > 0 && waves.peek().waveIsDone()){
            waves.remove();
            System.out.println("Done Wave");
            if (waves.size() > 0) waves.peek().activateWave();
        }

        // Due to timers using nanotime as well as integers, it is impossible to hold a timer for longer than two seconds without overflowing. 
        // This sucks, so we just count several times, hence the timerCount.
        if(flopTimer.isDone()){
            timerCount++;
            if(timerCount == 5) {
                for(EnemyChain e: enemyChains) e.flipMode();
                timerCount = 0;
            }
            flopTimer.reset();
        }
        
    }
}
