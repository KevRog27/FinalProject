package src;

import src.Timer;
import mayflower.*;
import java.util.*;

/**
 * Creates a set of enemies to spawn in a level.
 */
public class EnemyWave extends Actor{
    /**
     * Helper class, contains an enemy and a delay to spawn after
     */
    public class Subwave{
        EnemyChain e;
        float t;
        public Subwave(EnemyChain e, float t){
            this.e = e;
            this.t = t;
        }
        public float getTime(){return t;}
        public EnemyChain getEnemy() {return e;}
    }
    
    Queue<Subwave> subwavesToActivate;
    List<Subwave> subwaves;
    boolean isWaveActive;
    boolean isWaveOver;
    
    src.Timer timer;
    
    /**
     * creates an empty wave object
     */
    public EnemyWave(){
        subwavesToActivate = new LinkedList<Subwave>();
        subwaves = new LinkedList<Subwave>();
        isWaveActive = false;
        isWaveOver = false;
        timer = new src.Timer(0);
    }
    /**
     * Adds an enemychain to be spawned after delay 
     */
    public void addEnemyToWave(EnemyChain e, float delay){
        Subwave w = new Subwave(e, delay);
        subwavesToActivate.add(w);
        subwaves.add(w);
    }
    /**
     * Returns whether the player has beaten all enemies in the wave.
     */
    public boolean waveIsDone(){
        return isWaveActive && isWaveOver;
    }
    /**
     * Enables this wave, starting the timer to spawn enemies.
     */
    public void activateWave(){
        isWaveActive = true;
        timer.set((int)(subwavesToActivate.peek().getTime()));
    }
    public void act(){
        setLocation(-30, -30);
        
        if(!isWaveActive) return;
        
        // Activate Enemies
        if(subwavesToActivate.size() > 0 && timer.isDone()){
            Subwave w = subwavesToActivate.remove();
            EnemyChain e = w.getEnemy();
            e.setActive(true);
            w = subwavesToActivate.peek();
            if(w != null) timer.set((int)(w.getTime()));
        }
        
        
        // Check if the wave is over;
        boolean allDead = true;
        for(Subwave w : subwaves){
            if (!w.getEnemy().isDead()) {
                allDead = false;
            }
        }
        if(allDead) isWaveOver = true;
    }
}