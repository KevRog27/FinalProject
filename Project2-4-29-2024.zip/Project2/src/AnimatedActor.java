package src;

import mayflower.*;

/**
 * An actor that plays an animation.
 */
public class AnimatedActor extends Actor
{
    private Animation animation;
    private Timer t;
    
    /**
     * Create an actor with a frame rate of 12.
     */
    public AnimatedActor(){
        t = new Timer(1.0/12);
    }
    
    /**
     * Set the current animation.
     */
    public void setAnimation(Animation a){
        animation = a;
    }
    
    /**
     * Animation Logic. Advances frame and resets the timer when its timer is complete.
     */
    public void act(){
        

        if(animation == null){
            return;
        }

        if(t.isDone()){
            t.reset();
            MayflowerImage nextImage = new MayflowerImage(animation.getNextFrame());
            setImage(nextImage);
        }
    }


}