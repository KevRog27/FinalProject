package src;

import mayflower.*;

/**
 * Main Class
 *
 * @author Paul Berend
 * @version (a version number or a date)
 */
public class Main extends Mayflower
{
    /**
     * Create the mayflower instance.
     */
    public Main(){
        super("Space Force", 640, 480);
    }
    
    /**
     * Initialize the mayflower instance.
     */
    public void init(){
        Mayflower.setFullScreen(false);
        World w = new TitleScreen();

        Mayflower.setWorld(w);
    }
    
}
