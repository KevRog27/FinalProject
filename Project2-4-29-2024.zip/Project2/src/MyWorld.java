package src;

import mayflower.*;
import java.util.*;

/**
 * MyWorld class. All Levels extend this. 
 */
public class MyWorld extends World {
    public static Player jet;
    public float backgroundOffset;
    public MayflowerImage bgImg;
    
    ArrayList<EnemyChain> enemyChains;
    
    public static String previousBackground;
    public BackgroundFader bgf;

    protected List<EnemyWave> waves;
    
    src.Timer formationTimer;
    
    /**
     * Creates the level instance, with a given background.
     * Creates a player jet if there is not already one.
     */
    public MyWorld(String background) 
    {
        EnemyChain.idx = 0;
        Mayflower.setFullScreen(false);
        if(jet==null) jet = new Player(this, 320, 440);
        
        if(previousBackground != null) bgf = new BackgroundFader(this, previousBackground);
        
        bgImg = new MayflowerImage(background);
        setBackground(bgImg);
        previousBackground = background;
        
        addObject(jet, jet.getX(), jet.getY());
        setFont("impact", 20);
        
        enemyChains = new ArrayList<EnemyChain>();
        
        formationTimer = new src.Timer(10);
        
    }
    /**
     * Gets the current level and resets it in the event of player death.
     */
    public static void resetCurrent(){
        if(jet.getWorld() instanceof LevelOne) Mayflower.setWorld(new LevelOne());
        if(jet.getWorld() instanceof LevelTwo) Mayflower.setWorld(new LevelTwo());
        if(jet.getWorld() instanceof LevelThree) Mayflower.setWorld(new LevelThree());
        jet.dead = false;
    }
    
    /**
     * Returns the static instance of the player jet
     */
    public static Player getJet(){
        return jet;
    }
    
    /**
     * Scene Logic. Displays stats and controls the formation of enemies. Death logic.
     */
    public void act()
    {
        if(jet.getLives() <= 0)
            Mayflower.setWorld(new GameOver("LOSE"));
        
        removeText(0,30);
        showText("Lives: " + jet.getLives(), 20, 5, 25, Color.WHITE);
        showText("Score: " + jet.getScore(), 20, 5, 50, Color.WHITE);
        showText("Health: " + jet.getHealth(), 20, 5, 75, Color.WHITE);
        
        if(formationTimer.isDone()){
            formationTimer = new src.Timer(10);
            System.out.println("a");
            for(EnemyChain e : enemyChains) e.flipMode();
        }
    }
    
    
    
    
}