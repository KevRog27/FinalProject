package src;

import mayflower.*;

/**
 * Bullet Class
 * 
 * 
 * 
 * @author Paul Berend
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    float x;
    float y;
    float speed;
    float angle;
    float lifetime;
    public BulletOwner owner;
    
    /**
     * Creates a bullet at (x, y) with a given angle, at the given speed, with the bullets owner.
     */
    public Bullet(World w, float x, float y, float angle, float speed, BulletOwner bo){
        this.x = x;
        this.y = y;
        this.angle = angle;
        this.speed = speed;
        this.lifetime = 5*60;
        owner = bo;
        
        MayflowerImage img = new MayflowerImage("./assets/textures/heroMissile.png");
        img.scale(20, 20);
        setImage(img);
        
        w.addObject(this, (int)x,(int)y);
    }
    
    /**
     * Move the bullet along its appointed angle.
     */
    public void act(){
        lifetime -= 1;
        if (lifetime <= 0) getWorld().removeObject(this);
        
        x += (float)Math.cos(Math.toRadians(angle))*speed/60;
        y += (float)Math.sin(Math.toRadians(angle))*speed/60;
        
        setLocation((int)x,(int)y);
        setRotation((int)angle+90);
    }
}
