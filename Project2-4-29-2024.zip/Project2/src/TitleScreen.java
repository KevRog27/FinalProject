package src;

import mayflower.*;
import java.util.*;
import java.io.File;

/** 
 * Title screen for the game.
 */
public class TitleScreen extends World
{

    List<String> jets;
    int idx = 0;
    PreviewJet pj;
    public static MayflowerImage skin;
    
    /**
     * Creates a title screen for the game.
     */
    public TitleScreen()
    {
       
        MayflowerImage img = new MayflowerImage("./assets/textures/TitleScreen.png");
        img.scale(640, 480);
        setBackground(img);

        jets = new LinkedList<String>();
        File[] files = new File("./assets/textures/jets/").listFiles();
        for(File f : files){
            jets.add(f.getName());
        }
        pj = new PreviewJet();
        addObject(pj, 320-25, 290-25);
    }

    /**
     * Helper class. A preview of the character for the player. 
     */
    public class PreviewJet extends Actor {
        /**
         * Create the preview.
         */
        public PreviewJet() {setImage("1hero.png"); }
        public void act(){};
        /**
         * SetImage override, appends the proper path to s and scales the image.
         */
        public void setImage(String s){ 
            MayflowerImage img = new MayflowerImage("./assets/textures/jets/" + s);
            img.scale(50, 50);
            super.setImage(img); 
        }
        
    }
    /**
     * Scene Logic. Controls the start and preview skin.
     */
    public void act(){
        if(Mayflower.isKeyPressed(Keyboard.KEY_ENTER)){
            skin = pj.getImage();    
            Mayflower.setWorld(new LevelOne());
        }
        
        if(Mayflower.isKeyPressed(Keyboard.KEY_LEFT) || Mayflower.isKeyPressed(Keyboard.KEY_A)){
            idx -= 1;
            if(idx < 0) idx = jets.size() - 2;
            pj.setImage(jets.get(idx));
        }
        if(Mayflower.isKeyPressed(Keyboard.KEY_RIGHT) || Mayflower.isKeyPressed(Keyboard.KEY_D)){
            idx += 1;
            if(idx > jets.size() - 2) idx = 0;
            pj.setImage(jets.get(idx));
        }
        
    }
}
