package src;

import mayflower.*;

/**
 * Animation Class
 */
public class Animation 
{
    private MayflowerImage[] images;
    private int frameRate;
    private int currentFrame = 0;
    
    /**
     * Creates an animation with an array of filenames.
     */
    public Animation(String[] fileNames, int framerate){
       images = new MayflowerImage[fileNames.length];
       
       for(int i = 0; i < images.length; i++){
           images[i] = new MayflowerImage(fileNames[i]);
       }
       
       this.frameRate = framerate;
    }
    /**
     * Return the frame rate of the animation (12). 
     */
    public int getFrameRate(){
        return frameRate;
    }
    
    /**
     * Advances the animation and returns the next frame.
     */
    public MayflowerImage getNextFrame(){
        return images[currentFrame++ % images.length];
    }
    
    /**
     * Resizes the animation.
     */
    public void resize(int x, int y){
        for(int i = 0; i < images.length; i++)
            images[i].scale(x, y);
    }
    
    /**
     * Set Animation Transparency.
     */
    public void setTransparency(int x){
        for(int i = 0; i < images.length; i++)
            images[i].setTransparency(x);
    }
    
    /**
     * Flips the animation horozontally.
     */
    public void mirror(){
        for(int i = 0; i < images.length; i++)
            images[i].mirrorHorizontally();
    }
    
    /**
     * Crops the animation to the parameters. (x, y, w, h)
     */
    public void setBounds(int x, int y, int w, int h){
        for(int i = 0; i < images.length; i++)
            images[i].crop(x, y, w, h);
    }
    
    /**
     * Returns whether the animation is done.
     */
    public boolean isDone(){
        if (currentFrame+1 == images.length){
            return true;
        } return false;
    }
}