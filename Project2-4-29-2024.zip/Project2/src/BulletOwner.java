package src;


/**
 * Keep Track of the bullet type, to make sure the entity ignores its own bullets.
 */
public enum BulletOwner
{
    ENEMY, PLAYER;
}
