package src;
import mayflower.*;

/**
 * Actor that fades out for the next scene.
 */
public class BackgroundFader extends Actor
{
    float fade;
    MayflowerImage img;
    
    /**
     * Create a fader in world w with an image of img.
     */
    public BackgroundFader(World w, String img){
        this.img = new MayflowerImage(img);
        setImage(this.img);
        fade = 0;
        w.addObject(this, 0, 0);
    }
    
    /**
     * Fader Logic. Increases the fade timer and sets its own transparency.
     */
    public void act(){
        fade += 1;
        
        if(fade >= 100) getWorld().removeObject(this);

        getImage().setTransparency((int)fade);
        //setLocation(getX(), getY() + 1);
        
    }
}
