package src;

import mayflower.*;
import src.Timer;

/**
 * Main Player class. 
 */
public class Player extends Actor{
    float x, y;
    float speed;
    float cooldownDuration;
    Timer cooldownTimer;
    
    int health;
    int lives;
    int score;
    
    float invulnTime = 3;
    Timer invulnTimer;

    boolean dead;
    src.Timer deathTimer;
    
    /**
     * Returns the current lives. 
     */
    public int getLives(){return lives;}
    /**
     * Returns the current score. 
     */
    public int getScore(){return score;}
    /**
     * Returns the current health. 
     */
    public int getHealth(){return health;}
    
    /**
     * Player Logic. Controls movement and firing, and running out of health.
     */
    public void act(){
        
        if(!dead) {
            float dx = 0;
            if(Mayflower.isKeyDown(Keyboard.KEY_D) || Mayflower.isKeyDown(Keyboard.KEY_RIGHT))     dx += speed;
            if(Mayflower.isKeyDown(Keyboard.KEY_A) || Mayflower.isKeyDown(Keyboard.KEY_LEFT))    dx -= speed;
            if((Mayflower.isKeyDown(Keyboard.KEY_W) || Mayflower.isKeyDown(Keyboard.KEY_SPACE) || Mayflower.isKeyDown(Keyboard.KEY_UP)) && cooldownTimer.isDone()) fire();
            
            
            
            x += dx/60;
            if (x < 0) x = 0;
            if (x > Mayflower.getWidth() - 20) x = Mayflower.getWidth() - 20;
            setLocation((int)x,(int)y);
        }
        
        if (isTouching(Bullet.class)){
            Bullet b = getOneIntersectingObject(Bullet.class);
            if(b.owner == BulletOwner.ENEMY){
                removeTouching(Bullet.class);
                if(invulnTimer.isDone()){
                    health -= 1;
                    invulnTimer.reset();
                }
            }
            
        }
        if (lives == 0) {
            // game over
            System.out.print("megaDeath");
        }
        if (health == 0){
            // reload level
            
            if(!dead) getWorld().addObject(new Explosion(), getX(), getY());
            dead = true;
            setLocation(-30, -30);
            if(deathTimer == null) deathTimer = new src.Timer(3);
            if(deathTimer.isDone()){
                deathTimer = null;
                MyWorld.resetCurrent();
                System.out.print("death");
                health = 3;
                lives -= 1;
            }
        }
        
        if(invulnTimer.isDone()){
            getImage().setTransparency(0);
        } else {
            getImage().setTransparency((int)(Math.sin(invulnTimer.getTimeLeft())+1)*50);
        }
    }
    
    /**
     * Add to the players score
     * @param val
     */
    public void addScore(int val) {
        score += val;
        System.out.println(score);
    }
    
    /**
     * Create a player at (x, y), in world w.
     */
    public Player(World w, float x, float y){
        dead = false;
        this.x = x;
        this.y = y;
        cooldownDuration = 0.5f;
        speed = 320f;
        cooldownTimer = new Timer((double)(cooldownDuration));
        invulnTimer = new Timer((double)(invulnTime));
        
        health = 3;
        lives = 3;
        
        MayflowerImage img = TitleScreen.skin;
        img.scale(20, 20);
        //img.scale(20, 20);
        setImage(img);
        
        //w.addObject(this, (int)x, (int)y);
    }
    
    /**
     * Fire Bullet at players position, north.
     */
    private void fire(){
        cooldownTimer.reset();
        new Bullet(getWorld(), x, y, -90, 250, BulletOwner.PLAYER);
    }
}