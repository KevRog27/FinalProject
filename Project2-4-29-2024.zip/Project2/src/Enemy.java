package src;

import mayflower.*;
/**
 * Game Enemies.
 */
public class Enemy extends Actor
{
    private float x;
    private float y;
    private float speed;
    private float angle;
    private float followDistance;
    private int id;
    private EnemyMode currentMode;
    private boolean inFormation;
    private boolean active;
    private boolean onScreen;
    boolean alive;
    
    Enemy follow = null;

    src.Timer fireTimer;
    
    /**
     * Spawns an Enemy at a default location.
     */
    public Enemy(World w){
        this(w, 0, 0, 0);
    }
    /**
     * Helper Method for splitting the chain; Keeps enemies at a constant distance when splitting.
     */
    public void doubleFollowDistance(){
        followDistance *= 2;
    }
    /**
     * Spawns in an Enemy at X, Y, with an id for the formation position.
     */
    public Enemy(World w, float x, float y, int id){
        this.x = x;
        this.y = y;
        this.id = id;
        speed = 200;
        angle = 180;
        followDistance = 30;
        currentMode = EnemyMode.FLYING;
        inFormation = false;
        MayflowerImage img = new MayflowerImage("./assets/textures/villianJet.png");
        img.scale(20, 20);
        setImage(img);
        setActive(false);
        onScreen = false;
        alive = true;
        w.addObject(this, (int)x, (int)y);

        fireTimer = new src.Timer(Math.random()*5);
    }
    /**
     * Returns whether this enemy is dead.
     */
    public boolean isDead(){
        // System.out.println(!alive);
        return !alive;
    }
    /**
     * Gets the enemies current X position.
     */
    public float getXPos() {return x;}
    /**
     * Gets the enemies current Y position.
     */
    public float getYPos() {return y;}
    /**
     * Returns whether a point is 'out of bounds', or offscreen.
     */
    private boolean isPointOOB(float x, float y){
        if (x < 0 || y < 0) return true;
        if (x > Mayflower.getWidth() || y > Mayflower.getHeight()) return true;
        return false;
    }
    /**
     * Sets whether the enemy is Active or Inactive.
     */
    public void setActive(boolean active){
        this.active = active;
        if(fireTimer != null) fireTimer.reset();
        if(active) {
            setLocation(x, y);
            getImage().setTransparency(0);
        }
        else {
            setLocation(-30, -30);
            getImage().setTransparency(100);
        }
    }
    /**
     * Returns whether the enemy is Active or Inactive.
     */
    public boolean getActive() {return active;}
    /**
     * Act Method. Contains Logic for Flying, Formation, Firing, Fencing, Bullet Collision, and Death.
     */
    public void act(){
        // DEBUG STATEMENT REMOVE L8R
        if(DemoScene.DEBUG && Mayflower.isKeyPressed(Keyboard.KEY_SPACE)) flipMode();
        if(!active) return;
        
        float currentSpeed = speed;
        if(currentMode == EnemyMode.FLYING){
            if (inFormation) inFormation = false;
            // IF enemy has a follow target...
            if(follow != null){
                // Point at next in chain
                float tx = follow.getXPos();
                float ty = follow.getYPos();
                lookAt(tx, ty);
            
                // Change Speed for consistant follow distance
                currentSpeed = speed * getDistance(tx, ty) / followDistance;
            } else {
                // IF there is no follow target, this enemy is the front of the chain.
                // Rotate the enemy based on the system time.
                if(onScreen){
                    float a = (float)Math.cos(Math.toRadians(System.currentTimeMillis()/50*id));
                    angle += 90*a/60;
                } else {
                    lookAt(320, 240);
                }
            }
            // Constrain angle to 0<a<360
            while(angle >= 360) angle -= 360;
            while(angle < 0  ) angle += 360;
                
        } else if (currentMode == EnemyMode.FORMATION){
            int gSize = 30;
            int gWidth = 10;
            int gHeight = 5;
            
            int gY = id % gHeight;
            int gX = (int)(id/gHeight);
            
            float offX = (Mayflower.getWidth() - gWidth*gSize) / 2;
            float offY = (Mayflower.getHeight() - gHeight*gSize) / 3;
            
            //offX += 50 * Math.sin(System.currentTimeMillis()/1000);
            
            float targetX = 30 * gX + offX;
            targetX += 50*Math.sin(System.currentTimeMillis()/1000.0);
            
            float targetY = 30 * gY + offY;
            
            if(getDistance(targetX, targetY) < 5 || inFormation){
                if (!inFormation) inFormation = true;
                currentSpeed = 0;
                x = targetX;
                y = targetY;
                lookAt(x, y + 10);
            } else {
                lookAt(targetX, targetY);
            }
        }
        
        x += Math.cos(Math.toRadians(angle))*currentSpeed/60;
        y += Math.sin(Math.toRadians(angle))*currentSpeed/60;
        
        // Simple Fencing, allowing them to fly in from offscreen.
        if(!isPointOOB(x, y)) onScreen = true;
        if(onScreen){
            if (x < -25) {x = -25; angle += 5;}
            if (y < -25) {y = -25; angle += 5;}
            if (x > Mayflower.getWidth()          ) {x = Mayflower.getWidth()          ; angle += 5;} 
            if (y > Mayflower.getHeight()*2/3 - 20) {y = Mayflower.getHeight()*2/3 - 20; angle += 5;}
        }
        
        
        
        setLocation(x, y);
        setRotation((int)angle+90);
        
        if (isTouching(Bullet.class)){
            Bullet b = getOneIntersectingObject(Bullet.class);
            if(b.owner == BulletOwner.PLAYER){
                removeTouching(Bullet.class);
                die();
            }
            
        }
        if(follow != null && follow.isDead()) follow = null;
        
        // Fire once per every 5 seconds (on average).
        if(DemoScene.DEBUG&&Mayflower.isKeyPressed(Keyboard.KEY_F)) fireTimer.set(0);
        if(fireTimer.isDone() && !MyWorld.getJet().dead) {
            fire();
            fireTimer = new src.Timer(Math.random()*10+5);
        }
    }
    /**
     * Kills the enemy and deactivates it. 
     */
    private void die() {
        MyWorld.jet.addScore(100);
        getWorld().addObject(new Explosion(), (int)x, (int)y);
        alive = false;
        setActive(false);
    }
    
    /**
     * Gets the distance of the enemy to a given point.
     */
    private float getDistance(float x, float y){
        float dx = this.x - x;
        float dy = this.y - y;
        return (float)Math.sqrt(dx*dx+dy*dy);
    }
    /**
     * Changes the mode of the enemy. If its currently in flight mode, change to formation,
     * and vice versa.
     */
    void flipMode(){
        if(currentMode == EnemyMode.FLYING) currentMode = EnemyMode.FORMATION;
        else currentMode = EnemyMode.FLYING;
    }
    
    /**
     * Points the enemy at the given point.
     * Calculates the angle the enemy needs to be in order to point towards point (px, py).
     */
    private void lookAt(float px, float py){
        // Calculate the slope between the current position and target
        float dx = px - x;
        float dy = py - y;
        float slope = dy / dx;
        
        // Use atan to convert that to an angle, and store it in the enemies' angle variable.
        angle = (float)Math.toDegrees(Math.atan(slope));
        // atan only has a range of -90<a<90.
        // add 180 degrees if dx is negative to get a fuller range.
        if (dx < 0) angle += 180;
    }
    /**
     * Returns an angle to a point that the entity should look at, defined as (px ,py).
     */
    private float getLookAngle(float px, float py){
        // Calculate the slope between the current position and target
        float dx = px - x;
        float dy = py - y;
        float slope = dy / dx;
        
        // Use atan to convert that to an angle, and store it in the enemies' angle variable.
        float a = (float)Math.toDegrees(Math.atan(slope));
        // atan only has a range of -90<a<90.
        // add 180 degrees if dx is negative to get a fuller range.
        if (dx < 0) a += 180;
        return a;
    }
    /**
     * Turns the enemy toward the given point at turnSpeed, in degrees/second.
     */
    private void turnTowards(float px, float py,float turnSpeed){
        float dx = px - x;
        float dy = py - y;
        float targetAngle = (float)Math.toDegrees(Math.atan(dy/dx));
        if (dx < 0) targetAngle += 180;
        turnTowards(targetAngle, turnSpeed);
    }
    /**
     * Turns the enemy toward the given angle at turnSpeed, in degrees/second.
     */
    private void turnTowards(float a, float turnSpeed){
        float targetAngle = a;
        while(targetAngle > 360) targetAngle -= 360;
        while(targetAngle < 0  ) targetAngle += 360;

        if (targetAngle - angle > 180) angle -= turnSpeed/60;
        if (targetAngle - angle < 180) angle += turnSpeed/60;
        if(Math.abs(targetAngle - angle) < 5) angle = targetAngle;
    }
    
    /**
     * Returns the enemies current facing angle.
     */
    public float getAngle(){
        return angle;
    }
    
    /**
     * Sets the enemy that an enemy is following.
     */
    public void setFollowTarget(Enemy e){
        follow = e;
    }
    /**
     * Spawns a bullet that targets the player.
     */
    
    private void fire(){
        double a = getLookAngle(MyWorld.jet.getX(), MyWorld.jet.getY()) + Math.random()*4-2;
        new Bullet(getWorld(), x, y, (float)a, 250, BulletOwner.ENEMY);
    }
}
