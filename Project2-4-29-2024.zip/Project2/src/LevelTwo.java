package src;

import java.util.LinkedList;

import mayflower.*;
/**
 * Level Two. 
 */
public class LevelTwo extends MyWorld
{
    /**
     * Creates level one, wiht 32 Enemies.
     */
    public LevelTwo()
    {
        super("./assets/textures/backgrounds/level2.png");
        
        EnemyWave wave = new EnemyWave();
        EnemyChain e1 = new EnemyChain(this, 310, -20, 7);
        EnemyChain e2 = new EnemyChain(this, 310, -20, 9);
        EnemyChain e3 = new EnemyChain(this, 310, -20, 9);
        EnemyChain e4 = new EnemyChain(this, 310, -20, 7);
        enemyChains.add(e1);
        enemyChains.add(e2);
        enemyChains.add(e3);
        enemyChains.add(e4);
        
        wave.addEnemyToWave(e1, 1);
        wave.addEnemyToWave(e2, 5);
        wave.addEnemyToWave(e3, 15);
        wave.addEnemyToWave(e4, 5);
        
        addObject(wave, -30, -30);
        
        wave.activateWave();

        waves = new LinkedList<EnemyWave>();
        waves.add(wave);
    }
    /**
     * Sends player to next level when all enemies are dead.
     */
    public void act(){
        super.act();
            
        if(waves.get(0).waveIsDone())
            Mayflower.setWorld(new LevelThree());
                
    }
    
}