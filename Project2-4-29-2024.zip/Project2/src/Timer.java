package src;
/**
 * Replicates functionality of the Mayflower.Timer, but its less stupid.
 */
public class Timer {
   private double goal;
   private double start;
   
   /**
    * Creates a timer with 0 seconds.
    */
   public Timer() {
      this.reset();
      this.goal = 0;
   }
   
   /**
    * Creates a timer with goal seconds.
    */
   public Timer(double goal) {
      this.reset();
      this.goal = goal * 1000;
   }
   
   /**
    * Sets a timer's goal in seconds.
    */
   public void set(double goal) {
      this.reset();
      this.goal = goal * 1000;
   }

   /**
    * Adjusts the timer's goal by a given delta, in seconds. 
    */
   public void adjust(double diff) {
      this.goal += diff * 1000;
   }
   
   /**
    * Returns whether the Timer has been completed.
    */
   public boolean isDone() {
      return this.getTimeLeft() <= 0;
   }
   
   /**
    * Returns the amount of time left on the timer.
    */
   public double getTimeLeft() {
      return this.goal + this.start - System.currentTimeMillis();
   }
   
   /**
    * Returns whether the given amount is left on the timer.
    */
   public boolean isTimeLeft(double time) {
      return this.getTimeLeft() >= 0;
   }
   /**
    * Resets the timer.
    */
   public void reset() {
      this.start = System.currentTimeMillis();
   }
}
